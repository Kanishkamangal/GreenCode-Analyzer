// Benchmark: Bubble Sort
// Category: Sorting
// Algorithm: Bubble Sort - O(n^2)

package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {
	in := bufio.NewReader(os.Stdin)
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()

	var a []int64
	var x int64

	for {
		_, err := fmt.Fscan(in, &x)
		if err != nil {
			break
		}
		a = append(a, x)
	}

	for i := 0; i < len(a)-1; i++ {
		swapped := false

		for j := 0; j < len(a)-i-1; j++ {
			if a[j] > a[j+1] {
				a[j], a[j+1] = a[j+1], a[j]
				swapped = true
			}
		}

		if !swapped {
			break
		}
	}

	if len(a) == 0 {
		fmt.Fprintln(out, 0)
	} else {
		fmt.Fprintln(out, a[len(a)-1])
	}
}
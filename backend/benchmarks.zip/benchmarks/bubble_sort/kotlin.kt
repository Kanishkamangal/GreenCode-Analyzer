// Benchmark: Bubble Sort
// Category: Sorting
// Algorithm: Bubble Sort - O(n^2)

import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.StringTokenizer

fun main() {

    val br = BufferedReader(InputStreamReader(System.`in`))
    val a = ArrayList<Long>()

    var line: String?

    while (br.readLine().also { line = it } != null) {
        val st = StringTokenizer(line)

        while (st.hasMoreTokens()) {
            a.add(st.nextToken().toLong())
        }
    }

    for (i in 0 until a.size - 1) {
        var swapped = false

        for (j in 0 until a.size - i - 1) {
            if (a[j] > a[j + 1]) {
                val temp = a[j]
                a[j] = a[j + 1]
                a[j + 1] = temp
                swapped = true
            }
        }

        if (!swapped) break
    }

    println(if (a.isEmpty()) 0 else a[a.size - 1])
}
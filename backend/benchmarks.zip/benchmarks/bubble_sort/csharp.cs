// Benchmark: Bubble Sort
// Category: Sorting
// Algorithm: Bubble Sort - O(n^2)

using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        string input = Console.In.ReadToEnd();

        string[] parts = input.Split(
            new[] { ' ', '\n', '\r', '\t' },
            StringSplitOptions.RemoveEmptyEntries
        );

        List<long> a = new List<long>();

        foreach (string part in parts)
            a.Add(long.Parse(part));

        for (int i = 0; i < a.Count - 1; i++)
        {
            bool swapped = false;

            for (int j = 0; j < a.Count - i - 1; j++)
            {
                if (a[j] > a[j + 1])
                {
                    long temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) break;
        }

        Console.WriteLine(a.Count > 0 ? a[a.Count - 1] : 0);
    }
}